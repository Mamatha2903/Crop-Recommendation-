# AgriGuide

Run locally (JDK 17+):

    mkdir -p out && javac -d out src/agriguide/*.java
    java -cp out agriguide.AgriGuideServer

Open http://localhost:8080 — the Java server serves both the site and `POST /api/recommend`.

Docker: `docker build -t agriguide . && docker run -p 8080:8080 agriguide`

If you host the frontend separately, set `API_BASE` at the top of `src/agriguide/frontend/app.js`.
