package agriguide;

import java.util.List;

public class CropCatalog {
    public static List<CropItem> getAllItems() {
        return List.of(
            // --- CROPS ---
            new CropItem(
                "rice", "Rice", "Crop", "assets/crops/rice.jpg",
                60, 100, 35, 60, 35, 60, 5.5, 7.0, 20, 35, 70, 90, 100, 250,
                "Maintain standing water during early vegetative growth and ensure timely nitrogen top-dressing.",
                "High", "Kharif", 20, 2200
            ),
            new CropItem(
                "wheat", "Wheat", "Crop", "assets/crops/wheat.jpg",
                50, 90, 40, 65, 30, 55, 6.0, 7.5, 12, 25, 45, 70, 40, 110,
                "Sow in cool weather with well-drained loamy soil and irrigate at crown root initiation.",
                "Medium", "Rabi", 16, 2400
            ),
            new CropItem(
                "maize", "Maize", "Crop", "assets/crops/maize.jpg",
                70, 110, 40, 70, 30, 55, 5.8, 7.2, 18, 30, 55, 80, 60, 140,
                "Ensure good soil drainage and steady moisture during silking and grain filling.",
                "Medium", "Kharif,Rabi", 25, 2100
            ),
            new CropItem(
                "cotton", "Cotton", "Crop", "assets/crops/cotton.jpg",
                90, 140, 40, 65, 40, 65, 6.0, 8.0, 22, 35, 50, 75, 55, 110,
                "Grows best in deep black cotton soil with warm, sunny days during boll opening.",
                "Medium", "Kharif", 8, 7000
            ),
            new CropItem(
                "sugarcane", "Sugarcane", "Crop", "assets/crops/sugarcane.jpg",
                100, 150, 45, 75, 50, 85, 6.0, 7.5, 22, 36, 65, 85, 110, 220,
                "Requires abundant moisture and potassium during grand growth; mulch rows to conserve water.",
                "High", "All", 350, 350
            ),
            new CropItem(
                "chickpea", "Chickpea", "Crop", "assets/crops/chickpea.jpg",
                20, 45, 50, 80, 45, 80, 6.0, 8.0, 15, 28, 30, 55, 40, 90,
                "Avoid excess nitrogen or waterlogging; ideal as a winter/rabi pulse crop.",
                "Low", "Rabi", 8, 5500
            ),
            new CropItem(
                "ragi", "Finger Millet (Ragi)", "Crop", "assets/crops/ragi.jpg",
                40, 70, 25, 45, 25, 45, 5.5, 7.5, 20, 34, 50, 75, 50, 100,
                "Highly drought-resilient cereal suited for red loamy soils with moderate rainfall.",
                "Low", "Kharif", 8, 4000
            ),
            new CropItem(
                "groundnut", "Groundnut", "Crop", "assets/crops/groundnut.jpg",
                20, 45, 40, 70, 35, 60, 6.0, 7.2, 22, 33, 50, 75, 50, 110,
                "Loose sandy-loam soil helps pegs penetrate easily; apply gypsum at flowering.",
                "Medium", "Kharif,Zaid", 10, 6000
            ),
            new CropItem(
                "coffee", "Coffee", "Crop", "assets/crops/coffee.jpg",
                80, 120, 20, 40, 30, 50, 5.5, 6.5, 18, 28, 70, 90, 140, 240,
                "Grow under filtered shade on well-drained hill slopes rich in organic humus.",
                "Medium", "All", 6, 18000
            ),

            // --- FRUITS ---
            new CropItem(
                "mango", "Mango", "Fruit", "assets/crops/mango.jpg",
                40, 80, 25, 50, 40, 80, 5.5, 7.5, 24, 36, 50, 75, 50, 150,
                "Reduce irrigation right before flowering to encourage strong panicle emergence.",
                "Medium", "Zaid", 35, 4000
            ),
            new CropItem(
                "banana", "Banana", "Fruit", "assets/crops/banana.jpg",
                80, 120, 40, 75, 80, 140, 5.5, 7.0, 22, 34, 70, 90, 100, 220,
                "High potassium feeder—apply organic mulch and prop heavy bunches against wind.",
                "High", "All", 100, 1800
            ),
            new CropItem(
                "pomegranate", "Pomegranate", "Fruit", "assets/crops/pomegranate.jpg",
                40, 75, 25, 50, 45, 85, 6.5, 7.8, 22, 35, 35, 65, 35, 90,
                "Thrives in semi-arid climates with drip irrigation and well-drained loamy soil.",
                "Low", "All", 45, 4200
            ),
            new CropItem(
                "grapes", "Grapes", "Fruit", "assets/crops/grapes.jpg",
                30, 60, 60, 110, 90, 150, 6.0, 7.5, 18, 32, 45, 70, 50, 100,
                "Prune vines on schedule and avoid heavy rain during berry ripening.",
                "Medium", "Rabi", 60, 5000
            ),
            new CropItem(
                "papaya", "Papaya", "Fruit", "assets/crops/papaya.jpg",
                50, 90, 40, 70, 50, 90, 6.0, 7.0, 22, 35, 60, 85, 80, 160,
                "Requires strict drainage—even brief waterlogging can cause collar rot.",
                "Medium", "All", 150, 1500
            ),
            new CropItem(
                "orange", "Orange", "Fruit", "assets/crops/orange.jpg",
                40, 75, 20, 45, 30, 60, 5.8, 7.2, 16, 30, 55, 80, 75, 140,
                "Provide micronutrients (zinc and magnesium) and avoid water stagnation around the trunk.",
                "Medium", "Rabi", 50, 3500
            ),
            new CropItem(
                "apple", "Apple", "Fruit", "assets/crops/apple.jpg",
                30, 60, 50, 90, 80, 140, 5.5, 6.8, 10, 22, 55, 80, 80, 140,
                "Needs winter chilling hours in temperate regions and well-aerated loamy soil.",
                "Medium", "Zaid", 40, 6000
            ),
            new CropItem(
                "watermelon", "Watermelon", "Fruit", "assets/crops/watermelon.jpg",
                70, 110, 30, 55, 40, 70, 6.0, 7.2, 24, 36, 45, 70, 40, 85,
                "Warm temperatures and sandy-loam beds produce sweeter fruits; cut water near harvest.",
                "Medium", "Zaid", 80, 1200
            ),
            new CropItem(
                "coconut", "Coconut", "Fruit", "assets/crops/coconut.jpg",
                30, 60, 20, 45, 50, 90, 5.5, 7.5, 24, 35, 70, 92, 130, 250,
                "Responds well to organic manure, potassium, and regular basin irrigation in dry months.",
                "High", "All", 40, 3000
            )
        );
    }
}