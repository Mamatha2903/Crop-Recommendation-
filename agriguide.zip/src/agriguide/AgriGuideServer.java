package agriguide;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AgriGuideServer {

    private static final RecommendationService service = new RecommendationService();

    private static final Path FRONTEND = Path.of(
        System.getenv().getOrDefault("FRONTEND_DIR", "src/agriguide/frontend")
    ).toAbsolutePath().normalize();

    public static void main(String[] args) throws IOException {
        int port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.createContext("/api/recommend", AgriGuideServer::handleRecommend);
        server.createContext("/", AgriGuideServer::handleStatic);
        server.setExecutor(null);
        server.start();
        System.out.println("AgriGuide running at http://localhost:" + port + "  (frontend: " + FRONTEND + ")");
    }

    private static void handleStatic(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        if (path.equals("/")) path = "/index.html";
        Path file = FRONTEND.resolve(path.substring(1)).normalize();
        if (!file.startsWith(FRONTEND) || !Files.isRegularFile(file)) {
            sendJson(exchange, 404, "{\"error\":\"Not found\"}");
            return;
        }
        String name = file.getFileName().toString().toLowerCase();
        String type = name.endsWith(".html") ? "text/html; charset=UTF-8"
            : name.endsWith(".css") ? "text/css; charset=UTF-8"
            : name.endsWith(".js") ? "application/javascript; charset=UTF-8"
            : name.endsWith(".jpg") || name.endsWith(".jpeg") ? "image/jpeg"
            : name.endsWith(".png") ? "image/png"
            : name.endsWith(".svg") ? "image/svg+xml" : "application/octet-stream";
        byte[] bytes = Files.readAllBytes(file);
        exchange.getResponseHeaders().set("Content-Type", type);
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
    }

    private static void handleRecommend(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendJson(exchange, 405, "{\"error\":\"Use POST /api/recommend\"}");
            return;
        }

        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);

        double n = extractDouble(body, "nitrogen", 75);
        double p = extractDouble(body, "phosphorus", 45);
        double k = extractDouble(body, "potassium", 55);
        double ph = extractDouble(body, "ph", 6.5);
        double temp = extractDouble(body, "temperature", 27);
        double humidity = extractDouble(body, "humidity", 72);
        double rainfall = extractDouble(body, "rainfall", 120);
        String category = extractString(body, "category", "ALL");
        String season = extractString(body, "season", "");
        String irrigation = extractString(body, "irrigation", "");

        List<RecommendationService.RankedRecommendation> ranked =
            service.recommend(n, p, k, ph, temp, humidity, rainfall, category, season, irrigation);

        sendJson(exchange, 200, RecommendationService.toJson(ranked));
    }

    private static double extractDouble(String json, String key, double fallback) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)").matcher(json);
        return m.find() ? Double.parseDouble(m.group(1)) : fallback;
    }

    private static String extractString(String json, String key, String fallback) {
        Matcher m = Pattern.compile("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : fallback;
    }

    private static void sendJson(HttpExchange exchange, int status, String payload) throws IOException {
        byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
// Example fields to include in each recommended crop's JSON object:
// "name": "pomegranate",
// "match": 92,
// "water": "Low (Drip)",
// "yieldPerAcreQuintals": 45.0,
// "ratePerQuintal": 4200.0
