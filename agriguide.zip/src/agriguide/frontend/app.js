// Same-origin by default (the Java server also serves this page).
// If you host the frontend elsewhere, set API_BASE to the backend URL, e.g. "https://agriguide-api.onrender.com".
const API_BASE = location.protocol === "file:" ? "http://localhost:8080" : "";
const API_URL = API_BASE + "/api/recommend";

const $ = (id) => document.getElementById(id);
const FIELDS = ["nitrogen", "phosphorus", "potassium", "ph", "temperature", "humidity", "rainfall", "category"];

const PRESETS = {
  paddy:   { nitrogen: 85, phosphorus: 48, potassium: 45, ph: 6.2, temperature: 28, humidity: 82, rainfall: 190, category: "ALL" },
  orchard: { nitrogen: 70, phosphorus: 50, potassium: 95, ph: 6.4, temperature: 29, humidity: 75, rainfall: 130, category: "Fruit" },
  dryland: { nitrogen: 45, phosphorus: 40, potassium: 50, ph: 7.0, temperature: 29, humidity: 50, rainfall: 65,  category: "ALL" }
};
const SOILS = {
  loamy:    { nitrogen: 85, phosphorus: 48, potassium: 45, ph: 6.5, temperature: 28, humidity: 75, rainfall: 120 },
  black:    { nitrogen: 70, phosphorus: 50, potassium: 95, ph: 7.4, temperature: 30, humidity: 65, rainfall: 90 },
  alluvial: { nitrogen: 95, phosphorus: 60, potassium: 65, ph: 6.8, temperature: 27, humidity: 78, rainfall: 150 },
  laterite: { nitrogen: 55, phosphorus: 35, potassium: 40, ph: 5.8, temperature: 29, humidity: 80, rainfall: 170 }
};

const I18N = {
  en: {
    tagline: "Smart Crop & Fruit Recommendation System", print: "Print Farm Plan", langBtn: "ಕನ್ನಡ",
    heroTitle: "Grow the Right Crop for Your Soil & Climate",
    heroText: "Enter your soil nutrients, pH and local weather to get ranked crop and fruit recommendations with yield and return estimates.",
    kpiSoil: "Soil Fertility", kpiMatch: "Top Match", kpiWater: "Irrigation", kpiProfit: "Est. Top Return",
    step1: "1. Enter Farm Conditions", step2: "2. Ranked Recommendations",
    pPaddy: "Wetland / Paddy", pOrchard: "Tropical Fruit Orchard", pDry: "Semi-Arid Dryland",
    soilType: "Soil Type", season: "Season", irrigation: "Water / Irrigation", acres: "Land Area",
    temp: "Temperature", humidity: "Humidity", rainfall: "Rainfall", category: "Category Filter",
    recommend: "Recommend Crops & Fruits", compareTitle: "Side-by-Side Comparison (up to 3)",
    thCrop: "Crop / Fruit", thMatch: "Match", thWater: "Water Need", thYield: "Est. Yield", thReturn: "Est. Return",
    compare: "Compare", comparing: "✓ Comparing", best: "Best Match", suit: "Suitability Score",
    water: "Water", yield: "Est. Yield", ret: "Est. Return", qtl: "qtl",
    analyzing: "Analyzing soil & climate...", found: (n) => `Found ${n} ranked matches.`,
    offline: "Cannot reach the AgriGuide server. Start it with: java -cp out agriguide.AgriGuideServer",
    none: "No matching crops or fruits found.", search: "Search crop or fruit name...",
    fert: ["Optimal", "Low Fertility", "High Nutrient"],
    tips: { n: "Add urea / organic compost for nitrogen", p: "Apply DAP / rock phosphate for phosphorus",
            k: "Apply MOP (potash) for potassium", lime: "Apply agricultural lime to raise pH",
            gyp: "Add gypsum / organic matter to lower pH", ok: "NPK & pH are well-balanced; maintain organic mulch." },
    levels: { Low: "Low", Medium: "Medium", High: "High" }
  },
  kn: {
    tagline: "ಸ್ಮಾರ್ಟ್ ಬೆಳೆ ಮತ್ತು ಹಣ್ಣು ಶಿಫಾರಸು ವ್ಯವಸ್ಥೆ", print: "ಕೃಷಿ ವರದಿ ಮುದ್ರಿಸಿ", langBtn: "English",
    heroTitle: "ನಿಮ್ಮ ಮಣ್ಣು ಮತ್ತು ಹವಾಮಾನಕ್ಕೆ ಸರಿಯಾದ ಬೆಳೆ ಬೆಳೆಯಿರಿ",
    heroText: "ಮಣ್ಣಿನ ಪೋಷಕಾಂಶ, pH ಮತ್ತು ಹವಾಮಾನ ವಿವರಗಳನ್ನು ನಮೂದಿಸಿ; ಇಳುವರಿ ಮತ್ತು ಆದಾಯದ ಅಂದಾಜಿನೊಂದಿಗೆ ಸೂಕ್ತ ಬೆಳೆಗಳನ್ನು ಪಡೆಯಿರಿ.",
    kpiSoil: "ಮಣ್ಣಿನ ಫಲವತ್ತತೆ", kpiMatch: "ಉತ್ತಮ ಹೊಂದಾಣಿಕೆ", kpiWater: "ನೀರಾವರಿ", kpiProfit: "ಅಂದಾಜು ಆದಾಯ",
    step1: "1. ಜಮೀನಿನ ವಿವರ ನಮೂದಿಸಿ", step2: "2. ಶಿಫಾರಸು ಮಾಡಿದ ಬೆಳೆಗಳು",
    pPaddy: "ಭತ್ತ / ತೇವಭೂಮಿ", pOrchard: "ಉಷ್ಣವಲಯದ ಹಣ್ಣಿನ ತೋಟ", pDry: "ಅರೆ-ಒಣ ಭೂಮಿ",
    soilType: "ಮಣ್ಣಿನ ವಿಧ", season: "ಋತು", irrigation: "ನೀರಾವರಿ", acres: "ಜಮೀನಿನ ವಿಸ್ತೀರ್ಣ",
    temp: "ತಾಪಮಾನ", humidity: "ಆರ್ದ್ರತೆ", rainfall: "ಮಳೆ", category: "ವರ್ಗ",
    recommend: "ಬೆಳೆ ಮತ್ತು ಹಣ್ಣುಗಳನ್ನು ಸೂಚಿಸಿ", compareTitle: "ಬೆಳೆಗಳ ಹೋಲಿಕೆ (ಗರಿಷ್ಠ 3)",
    thCrop: "ಬೆಳೆ / ಹಣ್ಣು", thMatch: "ಹೊಂದಾಣಿಕೆ", thWater: "ನೀರಿನ ಅಗತ್ಯ", thYield: "ಅಂದಾಜು ಇಳುವರಿ", thReturn: "ಅಂದಾಜು ಆದಾಯ",
    compare: "ಹೋಲಿಸಿ", comparing: "✓ ಹೋಲಿಕೆಯಲ್ಲಿದೆ", best: "ಉತ್ತಮ ಆಯ್ಕೆ", suit: "ಸೂಕ್ತತೆ ಅಂಕ",
    water: "ನೀರು", yield: "ಅಂದಾಜು ಇಳುವರಿ", ret: "ಅಂದಾಜು ಆದಾಯ", qtl: "ಕ್ವಿಂಟಾಲ್",
    analyzing: "ಮಣ್ಣು ಮತ್ತು ಹವಾಮಾನ ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...", found: (n) => `${n} ಹೊಂದಾಣಿಕೆಗಳು ಸಿಕ್ಕಿವೆ.`,
    offline: "AgriGuide ಸರ್ವರ್ ಸಂಪರ್ಕಿಸಲಾಗಲಿಲ್ಲ.",
    none: "ಹೊಂದುವ ಬೆಳೆ ಅಥವಾ ಹಣ್ಣು ಸಿಗಲಿಲ್ಲ.", search: "ಬೆಳೆ ಅಥವಾ ಹಣ್ಣಿನ ಹೆಸರು ಹುಡುಕಿ...",
    fert: ["ಉತ್ತಮ", "ಕಡಿಮೆ ಫಲವತ್ತತೆ", "ಹೆಚ್ಚು ಪೋಷಕಾಂಶ"],
    tips: { n: "ಸಾರಜನಕಕ್ಕೆ ಯೂರಿಯಾ / ಸಾವಯವ ಗೊಬ್ಬರ ಹಾಕಿ", p: "ರಂಜಕಕ್ಕೆ DAP / ರಾಕ್ ಫಾಸ್ಫೇಟ್ ಹಾಕಿ",
            k: "ಪೊಟ್ಯಾಶಿಯಂಗೆ MOP ಹಾಕಿ", lime: "pH ಹೆಚ್ಚಿಸಲು ಸುಣ್ಣ ಹಾಕಿ",
            gyp: "pH ಕಡಿಮೆ ಮಾಡಲು ಜಿಪ್ಸಂ / ಸಾವಯವ ಪದಾರ್ಥ ಸೇರಿಸಿ", ok: "NPK ಮತ್ತು pH ಸಮತೋಲನದಲ್ಲಿವೆ; ಹೊದಿಕೆ (ಮಲ್ಚ್) ಮುಂದುವರಿಸಿ." },
    levels: { Low: "ಕಡಿಮೆ", Medium: "ಮಧ್ಯಮ", High: "ಹೆಚ್ಚು" }
  }
};

let lang = "en";
let latest = [];
let compare = [];
const t = () => I18N[lang];
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const inr = (n) => "₹" + Math.round(n).toLocaleString("en-IN");
const val = (id) => Number($(id).value);
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function fallbackImage(name) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240"><rect width="400" height="240" fill="#e8f5e9"/>` +
    `<text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#1b5e20" font-family="sans-serif" font-size="22" font-weight="bold">${esc(name)}</text></svg>`;
  return "data:image/svg+xml;utf8," + encodeURIComponent(svg);
}

function fertilizerTip() {
  const n = val("nitrogen"), p = val("phosphorus"), k = val("potassium"), ph = val("ph"), x = t().tips, out = [];
  if (n < 60) out.push(x.n);
  if (p < 40) out.push(x.p);
  if (k < 40) out.push(x.k);
  if (ph < 5.8) out.push(x.lime);
  if (ph > 7.8) out.push(x.gyp);
  return out.length ? out.join(" · ") : x.ok;
}

function updateKpis() {
  const avg = (val("nitrogen") + val("phosphorus") + val("potassium")) / 3;
  const f = t().fert;
  $("kpiSoil").textContent = avg < 45 ? f[1] : avg > 110 ? f[2] : f[0];
  $("kpiWater").textContent = $("irrigation").selectedOptions[0].textContent;
  $("soilAdvice").textContent = "🧪 " + fertilizerTip();
}

function profit(item, acres) { return item.yieldPerAcreQuintals * item.ratePerQuintal * acres; }

async function fetchRecommendations() {
  $("status-msg").textContent = t().analyzing;
  const payload = {
    soilType: $("soilType").value, season: $("season").value, irrigation: $("irrigation").value,
    nitrogen: val("nitrogen"), phosphorus: val("phosphorus"), potassium: val("potassium"), ph: val("ph"),
    temperature: val("temperature"), humidity: val("humidity"), rainfall: val("rainfall"), category: $("category").value
  };
  try {
    const res = await fetch(API_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!res.ok) throw new Error("Server status " + res.status);
    latest = await res.json();
    $("status-msg").textContent = t().found(latest.length);
    updateKpis();
    renderCards();
  } catch (err) {
    $("status-msg").textContent = t().offline;
    $("results-grid").innerHTML = "";
    latest = [];
  }
}

function renderCards() {
  const acres = val("acres") || 1;
  const q = $("search-box").value.trim().toLowerCase();
  const shown = latest.filter((c) => c.name.toLowerCase().includes(q));

  if (latest.length) {
    $("kpiMatch").textContent = latest[0].matchPercentage + "%";
    $("kpiProfit").textContent = inr(profit(latest[0], acres));
  } else {
    $("kpiMatch").textContent = $("kpiProfit").textContent = "–";
  }

  if (!shown.length) { $("results-grid").innerHTML = `<p class="empty">${t().none}</p>`; return; }

  $("results-grid").innerHTML = shown.map((c, i) => {
    const top = i === 0 && !q;
    const on = compare.some((x) => x.id === c.id);
    return `
      <article class="crop-card ${top ? "top-pick" : ""}">
        <div class="img-wrap">
          <img src="${esc(c.imageUrl)}" alt="${esc(c.name)}" loading="lazy" onerror="this.onerror=null;this.src='${fallbackImage(c.name)}'" />
          ${top ? `<span class="top-tag">${t().best}</span>` : ""}
        </div>
        <div class="crop-body">
          <div class="crop-top"><h3>${esc(c.name)}</h3><span class="badge ${esc(c.category.toLowerCase())}">${esc(c.category)}</span></div>
          <div class="score-bar"><div class="score-fill" style="width:${c.matchPercentage}%"></div></div>
          <p class="match-text">${t().suit}: <strong>${c.matchPercentage}%</strong></p>
          <p class="facts"><strong>${t().water}:</strong> ${t().levels[c.water] || esc(c.water)} · <strong>${t().yield}:</strong> ${(c.yieldPerAcreQuintals * acres).toFixed(1)} ${t().qtl}<br>
             <strong>${t().ret}:</strong> ${inr(profit(c, acres))}</p>
          <p class="ideal-range">${esc(c.idealRange)}</p>
          <p class="tip">${esc(c.tip)}</p>
          <button type="button" class="btn-secondary" data-id="${esc(c.id)}">${on ? t().comparing : t().compare}</button>
        </div>
      </article>`;
  }).join("");
}

function toggleCompare(id) {
  const i = compare.findIndex((c) => c.id === id);
  if (i >= 0) compare.splice(i, 1);
  else { if (compare.length >= 3) compare.shift(); const c = latest.find((x) => x.id === id); if (c) compare.push(c); }
  renderCompare();
  renderCards();
}

function renderCompare() {
  const acres = val("acres") || 1;
  $("compareSection").hidden = !compare.length;
  $("compareBody").innerHTML = compare.map((c) => `
    <tr><td><strong>${esc(c.name)}</strong></td><td>${c.matchPercentage}%</td><td>${t().levels[c.water] || esc(c.water)}</td>
    <td>${(c.yieldPerAcreQuintals * acres).toFixed(1)} ${t().qtl}</td><td>${inr(profit(c, acres))}</td></tr>`).join("");
}

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => { const v = t()[el.dataset.i18n]; if (typeof v === "string") el.textContent = v; });
  $("langBtn").textContent = t().langBtn;
  $("search-box").placeholder = t().search;
  updateKpis();
  renderCompare();
  renderCards();
}

function fill(obj) { Object.entries(obj).forEach(([k, v]) => { $(k).value = v; }); }

$("recommend-form").addEventListener("submit", (e) => { e.preventDefault(); fetchRecommendations(); });
$("soilType").addEventListener("change", () => { fill(SOILS[$("soilType").value]); fetchRecommendations(); });
["season", "irrigation"].forEach((id) => $(id).addEventListener("change", fetchRecommendations));
$("acres").addEventListener("input", () => { renderCards(); renderCompare(); });
["nitrogen", "phosphorus", "potassium", "ph"].forEach((id) => $(id).addEventListener("input", updateKpis));
$("presets").addEventListener("click", (e) => { const b = e.target.closest("[data-preset]"); if (b) { fill(PRESETS[b.dataset.preset]); fetchRecommendations(); } });
$("results-grid").addEventListener("click", (e) => { const b = e.target.closest("button[data-id]"); if (b) toggleCompare(b.dataset.id); });
$("search-box").addEventListener("input", renderCards);
$("langBtn").addEventListener("click", () => { lang = lang === "en" ? "kn" : "en"; applyLang(); });
$("printBtn").addEventListener("click", () => window.print());

updateKpis();
fetchRecommendations();
