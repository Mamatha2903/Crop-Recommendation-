package agriguide;

public record CropItem(
    String id,
    String name,
    String category, // "Crop" or "Fruit"
    String imageUrl,
    double minN, double maxN,
    double minP, double maxP,
    double minK, double maxK,
    double minPh, double maxPh,
    double minTemp, double maxTemp,
    double minHumidity, double maxHumidity,
    double minRainfall, double maxRainfall,
    String tip,
    String water,          // Low / Medium / High
    String seasons,        // comma list or "All"
    double yieldPerAcreQuintals,
    double ratePerQuintal
) {
    public double suitabilityScore(
        double n, double p, double k,
        double ph, double temp, double humidity, double rainfall
    ) {
        double sN = rangeScore(n, minN, maxN);
        double sP = rangeScore(p, minP, maxP);
        double sK = rangeScore(k, minK, maxK);
        double sPh = rangeScore(ph, minPh, maxPh);
        double sTemp = rangeScore(temp, minTemp, maxTemp);
        double sHum = rangeScore(humidity, minHumidity, maxHumidity);
        double sRain = rangeScore(rainfall, minRainfall, maxRainfall);

        double avg = (sN + sP + sK + sPh + sTemp + sHum + sRain) / 7.0;
        return Math.round(avg * 1000.0) / 10.0; // Percentage rounded to 1 decimal
    }

    private double rangeScore(double value, double min, double max) {
        if (value >= min && value <= max) {
            return 1.0;
        }
        double span = Math.max(1.0, max - min);
        double distance = (value < min) ? (min - value) : (value - max);
        return Math.max(0.0, 1.0 - (distance / span));
    }

    public boolean growsIn(String season) {
        return seasons.equals("All") || season == null || season.isBlank()
            || seasons.toLowerCase().contains(season.toLowerCase());
    }

    public String idealSummary() {
        return String.format(
            "N: %.0f-%.0f | P: %.0f-%.0f | K: %.0f-%.0f | pH: %.1f-%.1f | Temp: %.0f-%.0f°C | Rain: %.0f-%.0fmm",
            minN, maxN, minP, maxP, minK, maxK, minPh, maxPh, minTemp, maxTemp, minRainfall, maxRainfall
        );
    }
}