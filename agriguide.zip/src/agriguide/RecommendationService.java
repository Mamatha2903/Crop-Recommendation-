package agriguide;

import java.util.Comparator;
import java.util.List;

public class RecommendationService {

    public record RankedRecommendation(CropItem item, double matchPercentage) {}

    public List<RankedRecommendation> recommend(
        double n, double p, double k,
        double ph, double temp, double humidity, double rainfall,
        String categoryFilter,
        String season, String irrigation
    ) {
        return CropCatalog.getAllItems().stream()
            .filter(item -> categoryFilter == null
                || categoryFilter.isBlank()
                || categoryFilter.equalsIgnoreCase("ALL")
                || item.category().equalsIgnoreCase(categoryFilter))
            .map(item -> new RankedRecommendation(
                item,
                adjust(item, item.suitabilityScore(n, p, k, ph, temp, humidity, rainfall), season, irrigation)
            ))
            .sorted(Comparator.comparingDouble(RankedRecommendation::matchPercentage).reversed())
            .toList();
    }

    /** Off-season crops lose 10%; thirsty crops lose points when the farm is rainfed. */
    private static double adjust(CropItem c, double score, String season, String irrigation) {
        if (!c.growsIn(season)) score *= 0.90;
        if ("Rainfed".equalsIgnoreCase(irrigation)) {
            if (c.water().equals("High")) score *= 0.85;
            else if (c.water().equals("Medium")) score *= 0.95;
        }
        return Math.round(score * 10.0) / 10.0;
    }

    public static String toJson(List<RankedRecommendation> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            RankedRecommendation r = list.get(i);
            CropItem c = r.item();
            if (i > 0) sb.append(",");
            sb.append("{")
              .append("\"id\":\"").append(escape(c.id())).append("\",")
              .append("\"name\":\"").append(escape(c.name())).append("\",")
              .append("\"category\":\"").append(escape(c.category())).append("\",")
              .append("\"imageUrl\":\"").append(escape(c.imageUrl())).append("\",")
              .append("\"matchPercentage\":").append(r.matchPercentage()).append(",")
              .append("\"idealRange\":\"").append(escape(c.idealSummary())).append("\",")
              .append("\"match\":").append(r.matchPercentage()).append(",")
              .append("\"water\":\"").append(escape(c.water())).append("\",")
              .append("\"seasons\":\"").append(escape(c.seasons())).append("\",")
              .append("\"yieldPerAcreQuintals\":").append(c.yieldPerAcreQuintals()).append(",")
              .append("\"ratePerQuintal\":").append(c.ratePerQuintal()).append(",")
              .append("\"tip\":\"").append(escape(c.tip())).append("\"")
              .append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }
}